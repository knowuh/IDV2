var m = {t:50,r:50,b:50,l:50},
    w = d3.select('.plot').node().clientWidth - m.l - m.r,
    h = d3.select('.plot').node().clientHeight - m.t - m.b;

var plot = d3.select(".plot")
    .append('svg')
    .attr('class', 'canvas')
	.attr('width', w)
	.attr('height', h)
	.append('g')
	//.attr('transform', 'translate('+m.l+','+m.t+')');
//console.log(plot);

var scaleX = d3.scale.linear().domain([1,10]).range([m.r,w-m.l]),
    scaleY = d3.scale.linear().domain([1,10]).range([h-m.b,m.t]),
    scaleR = d3.scale.linear().domain([1,10]).range([4,24])


var setData = function (data) {
    console.log(data)
    
    var circles = plot.each( function(d,i){
        
        var draw_circles = d3.select(this)
        .selectAll('circle')
        .data(data)
        .enter()
        .append('circle')
        .attr('cx', function(d){ return scaleX(d.whenwasthelasttimeyoudrewapicture) })
        .attr('cy', function(d){ return scaleY(d.whenwasthelasttimeyouwenttothemfa) })
        .attr('r', function(d){ return scaleR(d.whenwasthelasttimeyouwenttothebeach) })
        .style('fill', 'red')
        .style('opacity', 0.5)
    
    })
};
    
$(document).ready( function () {
    continuouslyLoadData("1tL7m0JNa0CZwEyU9WmB3u8j5T829jqtbnu-26ibPp5E", setData);
});
    
    


